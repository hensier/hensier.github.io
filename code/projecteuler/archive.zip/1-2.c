#include<stdio.h>
int ans;
int main()
{
    ans=((3+999)*333>>1)+((5+995)*199>>1)-((15+990)*66>>1);
    printf("%d",ans);
    return 0;
}