s = str(1 << 1000)
ans = 0
for i in s:
    ans += int(i)
print(ans)